#ifndef CHATTY_H
#define CHATTY_H


#include <stdio.h>

typedef enum{
	false,
	true
}bool;		///< definition of bool type


#endif /* CHATTY_H */
